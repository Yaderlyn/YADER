
Para iniciar este proyecto primero debe realizar los siguientes pasos

1- Clonar el repositorio con git clone.
2- Instalar las dependencas, solo se necesita ejecutar npm install y el npm hara todo el trabajo.
3- Entrar a la carpeta 'db' y ejecutar el archivo sql llamado 'db.sql'
4- Configurar los accesos a la base de datos: En la carpeta 'config' hay un archivo js llamado 'db', alli se debe completar los siguientes campos:
    -Nombre de la Base de datos.
    -Usuario con el que se realizaran las operaciones a la base de datos.
    -Contraseña del usuario.